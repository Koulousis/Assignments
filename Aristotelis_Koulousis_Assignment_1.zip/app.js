$(document).ready(function () {


        //Show hide lists
        $("#courses").click(function () {
                $("#courses-list").removeClass("d-none")
                $("#trainers-list").addClass("d-none")
                $("#students-list").addClass("d-none")
                $("#assignments-list").addClass("d-none")
        })
        $("#trainers").click(function () {
                $("#courses-list").addClass("d-none")
                $("#trainers-list").removeClass("d-none")
                $("#students-list").addClass("d-none")
                $("#assignments-list").addClass("d-none")
        })
        $("#students").click(function () {
                $("#courses-list").addClass("d-none")
                $("#trainers-list").addClass("d-none")
                $("#students-list").removeClass("d-none")
                $("#assignments-list").addClass("d-none")
        })
        $("#assignments").click(function () {
                $("#courses-list").addClass("d-none")
                $("#trainers-list").addClass("d-none")
                $("#students-list").addClass("d-none")
                $("#assignments-list").removeClass("d-none")
        })

        //Append text to shown list
        $("#add").click(function () {
                let coursesHidden = $("#courses-list").hasClass("d-none");
                let trainersHidden = $("#trainers-list").hasClass("d-none");
                let studentsHidden = $("#students-list").hasClass("d-none");
                let assignmentsHidden = $("#assignments-list").hasClass("d-none");

                if (!coursesHidden) {
                        let txt = $('<li class="list-group-item courses-list-item"></li>').text($("#user-text").val());
                        $("#courses-list").append(txt);
                        $("#user-text").val("");
                }
                if (!trainersHidden) {
                        let txt = $('<li class="list-group-item trainers-list-item"></li>').text($("#user-text").val());
                        $("#trainers-list").append(txt);
                        $("#user-text").val("");
                }
                if (!studentsHidden) {
                        let txt = $('<li class="list-group-item students-list-item"></li>').text($("#user-text").val());
                        $("#students-list").append(txt);
                        $("#user-text").val("");
                }
                if (!assignmentsHidden) {
                        let txt = $('<li class="list-group-item assignments-list-item"></li>').text($("#user-text").val());
                        $("#assignments-list").append(txt);
                        $("#user-text").val("");
                }
        })

        $("#listdrop").click(function () {
                let coursesHidden = $("#courses-list").hasClass("d-none");
                let trainersHidden = $("#trainers-list").hasClass("d-none");
                let studentsHidden = $("#students-list").hasClass("d-none");
                let assignmentsHidden = $("#assignments-list").hasClass("d-none");
                $("#listdrop-options").empty();

                if (!coursesHidden) {
                        let editOptions = [];
                        let childAmount = document.getElementById("courses-list").children.length;
                        for (let i = 0; i < childAmount; i++) {
                                editOptions[i] = document.getElementById("courses-list").children[i].textContent;
                                let txt = $('<a class="dropdown-item" href="#"></a>').text(editOptions[i]);
                                $("#listdrop-options").append(txt);
                        }
                }
                if (!trainersHidden) {
                        let editOptions = [];
                        let childAmount = document.getElementById("trainers-list").children.length;
                        for (let i = 0; i < childAmount; i++) {
                                editOptions[i] = document.getElementById("trainers-list").children[i].textContent;
                                let txt = $('<a class="dropdown-item" href="#"></a>').text(editOptions[i]);
                                $("#listdrop-options").append(txt);
                        }
                }
                if (!studentsHidden) {
                        let editOptions = [];
                        let childAmount = document.getElementById("students-list").children.length;
                        for (let i = 0; i < childAmount; i++) {
                                editOptions[i] = document.getElementById("students-list").children[i].textContent;
                                let txt = $('<a class="dropdown-item" href="#"></a>').text(editOptions[i]);
                                $("#listdrop-options").append(txt);
                        }
                }
                if (!assignmentsHidden) {
                        let editOptions = [];
                        let childAmount = document.getElementById("assignments-list").children.length;
                        for (let i = 0; i < childAmount; i++) {
                                editOptions[i] = document.getElementById("assignments-list").children[i].textContent;
                                let txt = $('<a class="dropdown-item" href="#"></a>').text(editOptions[i]);
                                $("#listdrop-options").append(txt);
                        }
                }


                $(function(){
                        $(".dropdown-item").on('click', function(){
                                $("#user-text").val($(this).text());
                        });
                });


        })
























})