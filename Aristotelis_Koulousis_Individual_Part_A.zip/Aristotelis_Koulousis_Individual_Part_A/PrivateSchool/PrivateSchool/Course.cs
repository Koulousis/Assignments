﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateSchool
{
    class Course
    {
        public string Title { get; set; }
        public string Stream { get; set; }
        public string Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
      
        public List<Trainer> Trainers { get; set; } = new List<Trainer>();
        public List<Student> Students { get; set; } = new List<Student>();
        public List<Assignment> Assignments { get; set; } = new List<Assignment>();

        public static Course New()
        {
            Console.WriteLine("Please fill the following values for the course:");
            Console.Write("Course title:");
            string courseTitle = Console.ReadLine();
            Console.Write("Course stream:");
            string courseStream = Console.ReadLine();
            Console.Write("Course type:");
            string courseType = Console.ReadLine();
            Console.Write("Course start day:");
            int courseStartDay = Convert.ToInt32(Console.ReadLine());
            Console.Write("Course start month:");
            int courseStartMonth = Convert.ToInt32(Console.ReadLine());
            Console.Write("Course start year:");
            int courseStartYear = Convert.ToInt32(Console.ReadLine());
            Console.Write("Course end day:");
            int courseEndDay = Convert.ToInt32(Console.ReadLine());
            Console.Write("Course end month:");
            int courseEndMonth = Convert.ToInt32(Console.ReadLine());
            Console.Write("Course end year:");
            int courseEndYear = Convert.ToInt32(Console.ReadLine());

            //Courses.Add(new Course() {Title=courseTitle,Stream=courseStream,Type=courseType,StartDate = new DateTime(courseStartYear,courseStartMonth,courseStartDay), EndDate = new DateTime(courseEndYear,courseEndMonth,courseEndDay) });
            return new Course() { Title = courseTitle, Stream = courseStream, Type = courseType, StartDate = new DateTime(courseStartYear, courseStartMonth, courseStartDay), EndDate = new DateTime(courseEndYear, courseEndMonth, courseEndDay) };
        }        
    }
}
