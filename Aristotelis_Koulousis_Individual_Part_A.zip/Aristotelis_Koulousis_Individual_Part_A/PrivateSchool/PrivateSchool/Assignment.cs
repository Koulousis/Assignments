﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateSchool
{
    class Assignment
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime SubDateTime { get; set; }
        public int OralMark { get; set; }
        public int TotalMark { get; set; }

        public static Assignment New()
        {
            Console.Write("Assignment title:");
            string assignmentTitle = Console.ReadLine();
            Console.Write("Assignment description:");
            string assignmentDescription = Console.ReadLine();
            Console.Write("Assignment sub date day:");
            int assignmentSubDateTimeDay = Convert.ToInt32(Console.ReadLine());
            Console.Write("Assignment sub date month:");
            int assignmentSubDateTimeMonth = Convert.ToInt32(Console.ReadLine());
            Console.Write("Assignment sub date year:");
            int assignmentSubDateYear = Convert.ToInt32(Console.ReadLine());
            Console.Write("Assignment oral mark:");
            int assignmentOralMark = Convert.ToInt32(Console.ReadLine());
            Console.Write("Assignment total mark:");
            int assignmentTotalMark = Convert.ToInt32(Console.ReadLine());

            return new Assignment() { Title = assignmentTitle, Description = assignmentDescription, SubDateTime = new DateTime(assignmentSubDateYear, assignmentSubDateTimeMonth, assignmentSubDateTimeDay), OralMark = assignmentOralMark, TotalMark = assignmentTotalMark };
        }

        public override string ToString()
        {
            return $"Assignment title and description: {Title}, {Description}, the Submit day is: {SubDateTime.ToShortDateString()}, the Oral Mark is {OralMark} and the Total Mark is {TotalMark}";
        }
    }
}
