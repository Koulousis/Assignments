﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateSchool
{
    class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public int TuitionFees { get; set; }


        public static Student New()
        {
            Console.Write("Student first name:");
            string studentFirstName = Console.ReadLine();
            Console.Write("Student last name:");
            string studentLastName = Console.ReadLine();
            Console.Write("Student birth day:");
            int studentBirthDay = Convert.ToInt32(Console.ReadLine());
            Console.Write("Student birth month:");
            int studentBirthMonth = Convert.ToInt32(Console.ReadLine());
            Console.Write("Student birth year:");
            int studentBirthYear = Convert.ToInt32(Console.ReadLine());
            Console.Write("Student tuition fees:");
            int studentTuitionFees = Convert.ToInt32(Console.ReadLine());

            return new Student() { FirstName = studentFirstName, LastName = studentLastName, DateOfBirth = new DateTime(studentBirthYear, studentBirthMonth, studentBirthDay), TuitionFees = studentTuitionFees};
        }

        public override string ToString()
        {
            return $"Student name: {FirstName}, {LastName} and the Tuition Fees: {TuitionFees}";
        }
    }
}
