﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateSchool
{
    class Trainer
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Subject { get; set; }

        public static Trainer New()
        {
            Console.Write("Trainer first name:");
            string trainerFirstName = Console.ReadLine();
            Console.Write("Trainer last name:");
            string trainerLastName = Console.ReadLine();
            Console.Write("Trainer subject:");
            string trainerSubject = Console.ReadLine();

            return new Trainer() { FirstName = trainerFirstName, LastName = trainerLastName, Subject = trainerSubject };
        }

        public override string ToString()
        {
            return $"Trainer: {FirstName}, {LastName}";
        }
    }
}
