﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrivateSchool
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Course> CoursesList = new List<Course>();
            //The application must ask from the command prompt to input data to all the
            //entities, and it should give the option to add more than one entry at a time
            Runtime(CoursesList);

            //A list of all the students
            foreach (Course course in CoursesList)
            {
                foreach (Student student in course.Students)
                {
                    Console.WriteLine(student.ToString());
                }
            }

            //A list of all the trainers
            foreach (Course course in CoursesList)
            {
                foreach (Trainer trainer in course.Trainers)
                {
                    Console.WriteLine(trainer.ToString());
                }
            }

            //A list of all the assignments
            foreach (Course course in CoursesList)
            {
                foreach (Assignment assignment in course.Assignments)
                {
                    Console.WriteLine(assignment.ToString());
                }
            }

            //A list of all the courses
            foreach (Course course in CoursesList)
            {
                course.ToString();
            }

            //All the students per course
            foreach (Course course in CoursesList)                 
            {
                Console.WriteLine($"For the course: {course.Title}, the students are:");
                foreach (Student student in course.Students)
                {
                    Console.WriteLine(student.ToString());
                }
            }

            //All the trainers per course
            foreach (Course course in CoursesList)
            {
                Console.WriteLine($"For the course: {course.Title}, the trainers are:");
                foreach (Trainer trainer in course.Trainers)
                {
                    Console.WriteLine(trainer.ToString());
                }
            }

            //All the assignments per course
            foreach (Course course in CoursesList)
            {
                Console.WriteLine($"For the course: {course.Title}, the assignments are:");
                foreach (Assignment assignment in course.Assignments)
                {
                    Console.WriteLine(assignment.ToString());
                }
            }
        }

        static List<Course> Runtime(List<Course> CoursesList)
        {
            //Info fill loop
            Console.WriteLine("----------Welcome to course creation----------");
            Console.Write("How many courses do you want to add:");
            int coursesCounter = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("OK then...");
            for (int i = 1; i <= coursesCounter; i++)
            {
                //Course Creation
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine($"Course number:{i}");
                CoursesList.Add(Course.New());


                Console.Write($"\nHow many trainers do you want to add on this course:");
                int trainersCounter = Convert.ToInt32(Console.ReadLine());
                for (int j = 1; j <= trainersCounter; j++)
                {
                    //Trainer Creation
                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine($"Trainer number:{j}");
                    CoursesList[i - 1].Trainers.Add(Trainer.New());
                }

                Console.Write($"\nHow many student do you want to add on this course:");
                int studentsCounter = Convert.ToInt32(Console.ReadLine());
                for (int k = 1; k <= studentsCounter; k++)
                {
                    //Student Creation
                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine($"Student number:{k}");
                    CoursesList[i - 1].Students.Add(Student.New());
                }

                Console.Write($"\nHow many assignments do you want to add on this course:");
                int assignmentsCounter = Convert.ToInt32(Console.ReadLine());
                for (int l = 1; l <= assignmentsCounter; l++)
                {
                    //Student Creation
                    Console.WriteLine("----------------------------------------------");
                    Console.WriteLine($"Assignment number:{l}");
                    CoursesList[i - 1].Assignments.Add(Assignment.New());
                }
            }
            return CoursesList;
        }
    }
}
